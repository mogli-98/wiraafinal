import axiosInstance from "../lib/axiosInstance";

const PortfolioModal = {

    
    async Portfolio(data) {
        return await axiosInstance.get(
            `/portfolio/all/${data.user_id}?page=1&per_page=9`);
    },
    async addcomments(data) {
        return (await axiosInstance.post(
            `/portfolio/addComment`, data
        ))
    }

}
export default PortfolioModal;