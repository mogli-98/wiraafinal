import axiosInstance from "../lib/axiosInstance";

const ProfileModal = {

   


}
export default ProfileModal;