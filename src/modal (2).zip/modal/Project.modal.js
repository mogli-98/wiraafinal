import axiosInstance from "../lib/axiosInstance";

const ProjectModal = {

    async favproject(data){
        return(await axiosInstance.get(
            `/project/favorite/${data.id}`
        ))
    },
    async Allproject(data) {
        return (await axiosInstance.get(
            `/project?page=1&per_page=10
            `
        ));
    }


}
export default ProjectModal;