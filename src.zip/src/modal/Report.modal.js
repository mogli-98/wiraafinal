import axiosInstance from "../lib/axiosInstance";

const ReportModal = {

    


}
export default ReportModal;