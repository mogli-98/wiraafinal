import axiosInstance from "../lib/axiosInstance";

const SearchModal = {

    


}
export default SearchModal;