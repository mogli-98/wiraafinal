import React from 'react'

const PaymentSucess = () => {
    return (
        <div>
            <h1>Success-Payment</h1>
        </div>
    )
}

export default PaymentSucess
