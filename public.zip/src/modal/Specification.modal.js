import axiosInstance from "../lib/axiosInstance";

const SpecificationModal = {
 

   

}
export default SpecificationModal;