import axios from "axios";

const Settingupdate = {
    async Phonenumber(data){
        return( await axios.post(
            `setting/updateNumber/`,data
        ))
    }, 
    async City(data){
        return(await axios.post(
           `https://wiraa.com/api/Profile/GetCity` ,data
        ))
    },
    async addStartup(data){
        return(await axios.post(
           `https://wiraaback.azurewebsites.net/api/v1/startup/addStartup` ,data
        ))
    }
}
export default Settingupdate;