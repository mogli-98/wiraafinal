import axios from "axios";

const Affiliate = {
                                                                
    async allAffi(data) {
        return (await axios.get(
            `https://wiraaback.azurewebsites.net/api/v1/affiliate/visitor/1`
        ));
    },
    async Report(data) {
        return (await axios.get(
            `https://wiraaback.azurewebsites.net/api/v1/affiliate/report/1`  ,data        ))
    }

              
}
export default  Affiliate;